# Sample Data for MySQL
This dataset is a stripped version of MySQL [Employee Dataset](https://github.com/datacharmer/test_db).

