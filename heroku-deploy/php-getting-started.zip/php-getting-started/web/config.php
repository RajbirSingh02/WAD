<?php
// this is hard coding 
//$servername = "localhost";
//$username = "root";
//$password = "admin";
//$dbname = "employees";
//$url = parse_url(getenv("mysql://b4c7ffe5a5a37c:218c61d0@us-cdbr-east-02.cleardb.com/heroku_07c44eac08d0ae1?reconnect=true"));
$servername = "us-cdbr-east-02.cleardb.com";
$username = "b4c7ffe5a5a37c";
$password = "218c61d0";
$dbname = ("heroku_07c44eac08d0ae1");

?>